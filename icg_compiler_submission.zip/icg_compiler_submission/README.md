# End-to-end compiler: C++ subset to RISC-V assembly

Written in C++ with Flex and Bison. The compiler reads a program in a C/C++
subset, checks it, and writes a RISC-V (RV64IMFD) assembly file.

## Required simulator
**RARS 1.6** (RISC-V Assembler and Runtime Simulator), 64-bit mode.
Download `rars1_6.jar` from https://github.com/TheThirdOne/rars/releases
(a copy is kept in this directory as `rars.jar`). Java 8 or newer is required.

```
java -jar rars.jar rv64 nc me output/prog.s              # run a program
java -jar rars.jar rv64 nc me output/prog.s pa 10 20     # with command-line arguments
```
Options: `rv64` selects 64-bit mode, `nc` hides copyright text, `me` sends
simulator messages to stderr, `pa` passes the remaining words to `main` as
`argv`. The program exit code is the value returned by `main`.

## Build and run
```
make                       # builds ./rvcc
./rvcc prog.cpp            # writes output/prog.s
./rvcc prog.cpp out.s      # writes out.s
./rvcc -ir prog.cpp out.s  # also writes out.ir (three-address code)
./rvcc -p prog.cpp         # also prints the three-address code
./run.sh ./rvcc            # runs every file in test/
make clean
```
Requirements: `g++`, `make`, `flex`, `bison`. `run.sh` also needs `java` to
execute the generated assembly; without it the programs are only compiled.

## Compiler stages
1. `src/lexer.l` - tokens and lexical errors.
2. `src/parser.y` - grammar, syntax errors, command-line driver.
3. `src/ast.cpp`, `src/ast.h` - types, class and struct layout, constant evaluation, error log.
4. `src/codegen.cpp` - semantic checks and three-address code (the IR).
5. `src/backend.cpp` - translation of the IR into RISC-V assembly.
6. `runtime/runtime.c` - C library (printf, scanf, files, strings, math, heap).
   It is compiled by this compiler during `make` and appended to every output.

Build order: the compiler is first linked without the runtime, translates
`runtime/runtime.c`, and is then linked again with the result embedded.

## Target model
- Sizes: `char` 1, `short` 2, `int` 4, `long` 8, `float` 4, `double` 8, pointer 8.
- Every variable and temporary lives in a stack slot; each IR instruction
  loads its operands into `t0`-`t2` / `ft0`-`ft1` and stores the result back.
- Frame: `s0` is the frame pointer, `ra` is saved at `-8(s0)`, the caller's
  `s0` at `-16(s0)`, locals below them.
- Calling convention: arguments are stored in consecutive 8-byte stack slots
  starting at `0(sp)` of the caller; the callee reads them at `0(s0)`, `8(s0)`, ...
  Results are returned in `a0` (integers, pointers) or `fa0` (float, double).
  Variadic functions walk the same slots.
- Program entry `_start` builds `argv` (with the program name first), calls
  `main` and exits with its return value.
- Heap: bump allocator over the simulator `sbrk` service.
- Output uses simulator system calls (print character, file write/read/open/close).

## Supported features
Basic: arithmetic, logical and bitwise operators, if-else, for, while,
do-while, switch, int and char arrays, pointers, structures, printf/scanf
(and cout/cin), function calls with arguments, goto/break/continue, static.

Advanced: recursion, dynamic memory (malloc/free/new/delete), command-line
input (`argc`/`argv`), typedef, references, enum, union, `until` loop,
multi-level pointers, multi-dimensional arrays, function overloading,
classes and objects, single inheritance (base destructors run after derived
ones), public/private/protected (enforced), constructors with initialiser
lists, destructors, out-of-class member definitions, variadic functions
(`va_list`, `va_start`, `va_arg`, `va_end`), function pointers (including
typedef'd and as members), lambdas (`[]`, `[=]`, `[&]`, `[x, &y]`, `-> type`),
`auto`, file handling (fopen, fclose, fgets, fputs, fprintf, fscanf, fread,
fwrite, fseek, ftell, rewind, feof, rename).

Library: printf family (`%d %i %u %x %X %o %c %s %p %f %e %g %%`, width,
precision, flags, `l` modifier), scanf family, string functions, ctype,
`atoi/atol/atof/strtol`, `abs`, `qsort`, `rand/srand`, `exit`, and math
(`sqrt sin cos tan atan exp log log10 pow fabs floor ceil round fmod`).

Not supported: `virtual` functions, operator overloading, templates,
namespaces, exceptions, range-based for, multiple inheritance, static class
members, function-like macros, constructors/destructors on arrays of objects,
and automatic destructor calls when exiting a block via `break`, `continue`,
or `goto`.

Simulator limits: standard error goes to standard output; `remove` cannot
delete a file; `fopen` modes `r`, `w`, `a` only; `free` does not recycle memory.

## Tests
`test/` holds 38 valid programs (`t01`-`t38`) covering every feature above and
29 programs with deliberate errors (`e01`-`e29`).

| File | Meaning |
|------|---------|
| `t*.cpp` | must compile; assembly is run and compared with `t*.out` |
| `t*.in`, `t*.args` | optional standard input and command-line arguments |
| `t*.out` | expected output (reference output of a native build) |
| `e*.cpp` | must be rejected with diagnostics and no assembly file |

Directives written as comments inside a test (`EXPECT-IR`, `EXPECT-COUNT`,
`EXPECT-NOT-IR`, `EXPECT-ERR`, `EXPECT-EXIT`) check the generated IR and the
diagnostics. See the header of `run.sh`.

## Directory layout
```
src/       lexer.l  parser.y  ast.h  ast.cpp  codegen.cpp  backend.h  backend.cpp
runtime/   runtime.c
test/      t01..t38 (+ .out/.in/.args), e01..e29
Makefile   run.sh   rars.jar   README.md
```
